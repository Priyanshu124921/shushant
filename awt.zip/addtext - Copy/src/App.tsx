import { AddText } from "./components/AddText"

const App = () => {
  return (
    <div>
      <AddText/>
    </div>
  )
}

export default App