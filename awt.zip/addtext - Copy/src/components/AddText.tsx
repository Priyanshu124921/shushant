import React, { useState } from "react";

export const AddText:React.FC = () => {
  const [myList, setMyList] = useState<string[]>([]);
  const [textbox, setTextbox] = useState<string>("");
  const handleChange = (e:React.ChangeEvent<HTMLInputElement>) => {
    setTextbox(e.target.value);
  };
  const addText = () => {
    setMyList((prev) => [...prev, textbox]);
    setTextbox("");
  };
  return (
    <div>
      <input onChange={handleChange} value={textbox} type="text" />
      <button onClick={addText}>Add text</button>
      <div>
        {myList.map((item, ind) => {
          return <p key={ind}>{item}</p>;
        })}
      </div>
    </div>
  );
};


