import React from 'react'
import products from "./product.json";
import Card from './components/Card';

const App = () => {
  console.log(products);
  return (
    <div className='flex gap-5 flex-wrap justify-center'>
      {products.map((item, ind)=>{
        return(
          <Card item={item}/>
        )
      })}
    </div>
  )
}

export default App