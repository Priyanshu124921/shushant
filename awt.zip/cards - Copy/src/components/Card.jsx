import React from "react";
import { FaRegHeart } from "react-icons/fa6";


const Card = ({ item }) => {
  return (
    <div className="m-2 rounded-md shadow-2xl relative w-80">
      <img className="w-fit" src={item.image_url} alt="" />
      <div className="p-2">
        <h1 className="font-bold text-md">{item.title}</h1>
        <h1 className="">{item.description}</h1>
        <h1 className="text-red-500 font-bold">${item.price}</h1>
        <button className="bg-green-500 p-2 rounded-md w-full">Add to Cart</button>
      </div>
      <div className="h-12 w-12 rounded-full bg-white flex justify-center items-center absolute top-1 right-1">
        <FaRegHeart size={26}/>
      </div>
      
    </div>
  );
};

export default Card;
