import React, { useState } from "react";
import Form from "./components/Form";

const App = () => {
  const [data, setData] = useState([]);
  return (
    <div>
      <Form data={data} setData={setData} />
      <h3>Submitted Data:</h3>
      {data.map((item, index) => (
        <div className="border" key={index}>
          <strong>Id:</strong> {item.id}
          <br /> <strong>Name:</strong> {item.name}
          <br />
          <strong> Class:</strong> {item.class}
          <br /> <strong>Marks:</strong> {item.marks}
        </div>
      ))}
    </div>
  );
};

export default App;
