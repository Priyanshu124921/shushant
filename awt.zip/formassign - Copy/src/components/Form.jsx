import React, { useState } from "react";
import { toast } from "sonner";

const Form = ({data, setData}) => {
  
  const [formData, setFormData] = useState({
    id: "",
    name: "",
    class: "",
    marks: "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if(formData.id === "" || formData.name === "" || formData.class === "" || formData.marks === "") return toast.warning('Please fill all the fields');
    setData([...data, formData]); // Add the form data to the array
    setFormData({ id: "", name: "", class: "", marks: "" }); // Clear the form
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label htmlFor="">Enter Id</label>
        <input
          name="id"
          onChange={(e) => handleChange(e)}
          value={formData.id}
          className="border"
          type="text"
        />
        <br />
        <label htmlFor="">Enter Name</label>
        <input
          name="name"
          onChange={(e) => handleChange(e)}
          value={formData.name}
          className="border"
          type="text"
        />
        <br />
        <label htmlFor="">Enter Class</label>
        <input
          name="class"
          onChange={(e) => handleChange(e)}
          value={formData.class}
          className="border"
          type="text"
        />
        <br />
        <label htmlFor="">Enter Marks</label>
        <input
          name="marks"
          onChange={(e) => handleChange(e)}
          value={formData.marks}
          className="border"
          type="number"
        />
        <br />
        <button type="submit" className="border">Submit</button>
      </form>
    </div>
  );
};

export default Form;
