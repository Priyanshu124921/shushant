import React from "react";
import Search from "./pages/Search";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import MovieView from "./pages/MovieView";

const App = () => {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Search />} />
          <Route path="/movie/:id" element={<MovieView/>} /> 
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;
