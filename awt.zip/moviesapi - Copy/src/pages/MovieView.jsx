import { useParams } from "react-router-dom";

const MovieView = ({ movie = null }) => {

    const {id } = useParams();
    

  return (
    <div className="flex gap-4">
      {movie && (
        <>
          <div>
            <img src={movie.Poster} alt="poster" />
          </div>
          <div>
            <p className="font-bold">Movie Name: </p>
            <p>{movie.Title}</p>
            <h1 className="font-bold">Actors:</h1>
            <h1>{movie.Actors}</h1>
            <h1 className="font-bold">Genre:</h1>
            <h1>{movie.Genre}</h1>
            <h1 className="font-bold">Type:</h1>
            <h1>{movie.Type}</h1>
            <h1 className="font-bold">Movie Year:</h1>
            <h1>{movie.Year}</h1>
            <h1 className="font-bold">IMDB Rating:</h1>
            <h1>{movie.imdbRating}</h1>
            <h1 className="font-bold">Writer:</h1>
            <h1>{movie.Writer}</h1>
            <h1 className="font-bold">Story Line:</h1>
            <h1>{movie.Plot}</h1>
          </div>
        </>
      )}
    </div>
  );
};
export default MovieView;
