import { useState } from "react";
import MovieView from "./MovieView";
import { useNavigate } from "react-router-dom";

const Search = () => {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [movie, setMovie] = useState(null);
  const handleChange = (e) => {
    setQuery(e.target.value);
  };

  const handleSearch = async () => {
    setLoading(true);
    const baseUrl = import.meta.env.VITE_BACKEND_URL;
    const apiKey = import.meta.env.VITE_API_KEY;
    try {
      const res = await fetch(`${baseUrl}/?t=${query}&apikey=${apiKey}`);
      const data = await res.json();
      setMovie(data);
      console.log(data);
      setLoading(false);
      // navigate(`/movie/${data.imdbID}`);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="h-screen flex flex-col items-center justify-center gap-2">
      <h1>Search Movies</h1>
      <div>
        <input
          value={query}
          onChange={handleChange}
          className="p-2 border rounded-md"
          type="text"
        />
        <button
          onClick={handleSearch}
          className="py-2 px-6 bg-emerald-500 rounded-md"
        >
          Search
        </button>
        <div>{loading && <p>Loading ....</p>}</div>
      </div>

      <MovieView movie={movie} />
    </div>
  );
};
export default Search;
