import React from "react";
import Home from "./pages/Home";
import { TodoContextProvider } from "./contexts/TodoContext";

const App = () => {
  return (
    <TodoContextProvider>
      <Home />
    </TodoContextProvider>
  );
};

export default App;
