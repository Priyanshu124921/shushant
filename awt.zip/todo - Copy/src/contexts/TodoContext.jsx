import { createContext, useReducer, useState } from "react";

export const todoContext = createContext("");

const initialState=[];
function reducer(state, action) {
  switch (action.type) {
    case "ADD": {
      const item = action.payload;
      return [...state, item];
    }
    case "REMOVE": {
      const ind = action.payload;
      return state.filter((_, index) => index != ind);
    }
  }
}

export const TodoContextProvider = ({ children }) => {
  // 1. using context
  //const [todos, setTodos] = useState([]);
  // const addTodos = (todo) => {
  //   setTodos((prev) => [...prev, todo]);
  // };
  // const removeTodos = (ind) => {
  //   setTodos((prev) => prev.filter((_, i) => i != ind));
  // };

  //2. using use reducer and context
  const [state, dispatch]= useReducer(reducer, initialState);
  const handleAdd = (textBox) => {
    if (textBox != "") {
      dispatch({ type: "ADD", payload: textBox });
      // settextBox("");
    }
  };
  const handleRemove = (ind) => {
    dispatch({ type: "REMOVE", payload: ind });
  };
  const handleKeyDown=(e)=>{
    if(e.key==="Enter")
        handleAdd();
  }
  

  return (
    <todoContext.Provider value={{ state, handleAdd, handleRemove, handleKeyDown }}>
      {children}
    </todoContext.Provider>
  );
};
