import React, { useContext, useReducer, useState } from "react";
import { todoContext } from "../contexts/TodoContext";
// const initialState = [];
// function reducer(state, action) {
//   switch (action.type) {
//     case "ADD": {
//       const item = action.payload;
//       return [...state, item];
//     }
//     case "REMOVE": {
//       const ind = action.payload;
//       return state.filter((_, index) => index != ind);
//     }
//   }
//}

const Home = () => {
  const [textBox, settextBox] = useState("");
   
  // 1.using usereducer
  // const [state, dispatch] = useReducer(reducer, initialState);
  // const handleAdd = () => {
  //   if (textBox != "") {
  //     dispatch({ type: "ADD", payload: textBox });
  //     settextBox("");
  //   }
  // };
  // const handleRemove = (ind) => {
  //   dispatch({ type: "REMOVE", payload: ind });
  // };
  // const handleKeyDown=(e)=>{
  //   if(e.key==="Enter")
  //       handleAdd();
  // }


  // 2. using context
  // const {todos, addTodos, removeTodos}= useContext(todoContext);
  // const handleAdd = () => {
  //   if (textBox != "") {
  //     addTodos(textBox);
  //   }
  // };
  // const handleRemove = (ind) => {
  //   removeTodos(ind);
  // };
  // const handleKeyDown = (e) => {
  //   if (e.key === "Enter") handleAdd();
  // };

  //3. using reducer and context
  const {state, handleAdd, handleRemove, handleKeyDown}= useContext(todoContext);

  return (
    <div className="p-5">
      <h1 className="text-3xl font-bold">To do App</h1>
      <input
        value={textBox}
        onKeyDown={handleKeyDown}
        onChange={(e) => settextBox(e.target.value)}
        className="p-2 border rounded-md"
        type="text"
        placeholder="Enter your todo"
      />
      <button onClick={()=>handleAdd(textBox)} className="bg-green-500 p-2 rounded-md mt-3">
        Add
      </button>

      <div>
        {state && state.map((item, ind) => {
          return (
            <div className="flex w-1/2 justify-between p-2" key={ind}>
              <li>{item}</li>
              <button
                onClick={() => handleRemove(ind)}
                className="bg-red-500 p-2 rounded-md"
              >
                remove
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Home;
