//1. Create a class extends React.Component
//2. render ->return tsx
import React from 'react'
class GreetClass extends React.Component
{
    render()
    {
        return (
            <>
            Class Component 
            </>
        )
    }

}
export default GreetClass;