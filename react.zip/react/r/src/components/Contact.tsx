
const Contact=()=>{
   // const {city}=useParams();

    return (

        <>
       
        <div>Contact Page</div></>
    )
}
export default Contact;